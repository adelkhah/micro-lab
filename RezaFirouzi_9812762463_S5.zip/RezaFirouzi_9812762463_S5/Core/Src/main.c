/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include<stdio.h>
#include<string.h>
#include<time.h>
#include "LiquidCrystal.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef unsigned char byte;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;

/* USER CODE BEGIN PV */
int score = 0;
int mode = 0;
int game[4][20];
int n = 4;
int m = 20;
int last_interrupt = 0;
int jump_state = 0;
int is_showing = 0;
int sevseg_tick = 0;
byte ground[8] = {
		0x1F,
		  0x1F,
		  0x1F,
		  0x1F,
		  0x1F,
		  0x1F,
		  0x1F,
		  0x1F
};
byte first[8] = {
		0x04,
		  0x04,
		  0x04,
		  0x04,
		  0x04,
		  0x04,
		  0x04,
		  0x04
};
byte second[8] = {
		0x0E,
		  0x0E,
		  0x04,
		  0x0E,
		  0x15,
		  0x04,
		  0x0A,
		  0x11
};
byte third[8] = {
		0x15,
		  0x0E,
		  0x04,
		  0x1F,
		  0x1F,
		  0x04,
		  0x0E,
		  0x15
};


byte peh[8] = {
  0x00,
  0x00,
  0x01,
  0x01,
  0x1F,
  0x00,
  0x0E,
  0x04
};

byte reh[8] = {
	 0x00,
	  0x00,
	  0x00,
	  0x00,
	  0x01,
	  0x02,
	  0x04,
	  0x18
};

byte sheh[8] = {
  0x00,
  0x02,
  0x07,
  0x00,
  0x17,
  0x14,
  0x1C,
  0x00
};

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM4_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM2_Init(void);
/* USER CODE BEGIN PFP */
TIM_HandleTypeDef *pwm_timer = &htim2; // Point to PWM timer configured in CubeMX
uint32_t pwm_channel = TIM_CHANNEL_2;  // Specify configured PWM channel

void PWM_Start()
{
  HAL_TIM_PWM_Start(pwm_timer, pwm_channel);
}

void PWM_Change_Tone(uint16_t pwm_freq, uint16_t volume) // pwm_freq (1 - 20000), volume (0 - 1000)
{
  if (pwm_freq == 0 || pwm_freq > 20000)
  {
    __HAL_TIM_SET_COMPARE(pwm_timer, pwm_channel, 0);
  }
  else
  {
    const uint32_t internal_clock_freq = HAL_RCC_GetSysClockFreq();
    const uint16_t prescaler = 1;
    const uint32_t timer_clock = internal_clock_freq / prescaler;
    const uint32_t period_cycles = timer_clock / pwm_freq;
    const uint32_t pulse_width = volume * period_cycles / 1000 / 2;

    pwm_timer->Instance->PSC = prescaler - 1;
    pwm_timer->Instance->ARR = period_cycles - 1;
    pwm_timer->Instance->EGR = TIM_EGR_UG;
    __HAL_TIM_SET_COMPARE(pwm_timer, pwm_channel, pulse_width); // pwm_timer->Instance->CCR2 = pulse_width;
  }
}
void display_number(int a, int dp)
{
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, 1);
    if(dp == 1) HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, 0);
    int x1 = a & 1;
    int x2 = a & 2;
    int x3 = a & 4;
    int x4 = a & 8;
    if(x1 > 0) x1 = 1;
    if(x2 > 0) x2 = 1;
    if(x3 > 0) x3 = 1;
    if(x4 > 0) x4 = 1;

    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_8, x1);
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_9, x2);
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_10, x3);
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11, x4);
}


void turn_off()
{
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, 0);
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, 0);
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, 0);
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_15, 0);
}

void show_all(int a, int dp)
{
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, 1);
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, 1);
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, 1);
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_15, 1);
    display_number(a, dp);
}

void go_next_mode()
{
	mode += 1;
	mode %= 3;
	is_showing = 0;
}
void correct(int i, int j)
{
	setCursor(j, i);
	if(game[i][j] == -1){
		//print("#");
		write(0);
	}
	else if(game[i][j] == 0){
		print(" ");
	}
	else if(game[i][j] == 1){
		//print("I");
		write(1);
	}
	else if(game[i][j] == 2){
		//print("H");
		write(2);
	}
	else if(game[i][j] == 3){
		//print("X");
		write(3);
	}
}
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{

    if (htim->Instance == TIM3)
    {
    	if(mode == 0){
    		if(is_showing == 0){
    			clear();
    			setCursor(3, 1);
    			print("welcome to ");
    			setCursor(16, 1);
    			write(4);
    			setCursor(15, 1);
    			write(5);
    			setCursor(14, 1);
    			write(6);

    			is_showing = 1;
    		}
    	}
    	else if(mode == 1){

    		if(is_showing == 0){
    			clear();
    			for(int i = 0; i < n; i++){
					for(int j = 0; j < m; j++){
						correct(i, j);
					}
				}
    			is_showing = 1;
    			return;
    		}

    		score += 1;


    		if(game[2][2] == 2){
    			game[2][2] = 0;
    			correct(2,2);
    		}
    		if(game[1][2] == 2){
    		    game[1][2] = 0;
    		    correct(1,2);
    		}
    		if(game[0][2] == 2){
    		    game[0][2] = 0;
    		    correct(0, 2);
    		}
    		if(game[0][0] == 1){
    			game[0][0] = 0;
    			correct(0, 0);
    		}
    		if(game[1][0] == 1){
    			game[1][0] = 0;
    			correct(1, 0);
    		}
    		if(game[2][0] == 1){
    			game[2][0] = 0;
    			correct(2, 0);
    		}
    		for(int i = 1; i < m; i++){
    			if(game[0][i] == 1){
    				game[0][i] = 0;
    				game[0][i-1] = 1;
    				correct(0, i);
    				correct(0, i-1);
    			}
    			if(game[2][i] == 1){
    				game[2][i] = 0;
					game[2][i-1] = 1;
					correct(2, i);
					correct(2, i-1);
    			}
    		}
    		int tmp = rand();
			  if(tmp % 8 == 0){
				  game[0][m-1] = 1;
				  correct(0, m-1);
			  }
			  tmp = rand();
			  if(tmp % 8 == 0){
				  game[2][m-1] = 1;
				  correct(2, m-1);
			  }

    		if(jump_state == 3){
    			game[1][2] = 2;
    			correct(1, 2);
				jump_state = 2;
			}
			else if(jump_state == 2){
				if(game[0][2] == 1){
					game[0][2] = 3;
					PWM_Change_Tone(1, 0);
					correct(0, 2);
					go_next_mode();
				}
				else{
					game[0][2] = 2;
					correct(0, 2);
					jump_state = 1;
				}

			}
			else if(jump_state == 1){
				game[1][2] = 2;
				correct(1, 2);
				jump_state = 0;
			}
			else if(jump_state == 0){
				PWM_Change_Tone(1, 0);
				if(game[2][2] == 1){
					game[2][2] = 3;
					correct(2, 2);
					go_next_mode();
				}
				else{
					game[2][2] = 2;
					correct(2, 2);
				}
			}

    	}

    	else if(mode == 2){
    		if(is_showing == 0){
    			clear();

    			print("game over !!");
    			setCursor(0, 1);
    			print("score : ");
    			char s[5];
    			sprintf(s, "%d", score);
    			print(s);
    			is_showing = 1;
    		}


    	}

    }


    if (htim->Instance == TIM4){
    	sevseg_tick += 1;
    	  sevseg_tick %= 4;
    	  if(sevseg_tick == 0){
    			  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, 1);
    			  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, 0);
    			  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, 0);
    			  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_15, 0);
    			  display_number(score / 1000, 0);
    		  }
    		  else if(sevseg_tick == 1){
    			  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, 0);
    			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, 1);
    			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, 0);
    			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_15, 0);
    			display_number((score / 100) % 10, 0);
    		  }
    		  else if(sevseg_tick == 2){
    			  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, 0);
    			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, 0);
    			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, 1);
    			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_15, 0);
    			display_number((score / 10) % 10, 0);
    		  }
    		  else if(sevseg_tick == 3){
    			  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, 0);
    			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, 0);
    			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, 0);
    			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_15, 1);
    			display_number(score % 10, 0);

    		  }
    }
}


void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if(last_interrupt + 200 > HAL_GetTick()){
		return;
	}
	last_interrupt = HAL_GetTick();

    if (GPIO_Pin == GPIO_PIN_0)
    {

    	if(mode == 0){

    		for(int i = 0; i < m; i++){
    			game[3][i] = -1;
    		}
    		for(int i = 10; i < m; i++){
    		  	  int tmp = rand();
    		  	  if(tmp % 8 == 0){
    		  		  game[0][i] = 1;
    		  	  }
    		  	  tmp = rand();
    		  	  if(tmp % 8 == 0){
    		  		  game[2][i] = 1;
    		  	  }
    		    }
    		game[2][2] = 2;
    		go_next_mode();
    	}
    	else if(mode == 1){
    		// jump
    		PWM_Change_Tone(20, 1);
    		jump_state = 3;

    	}
    	else if(mode == 2){
    		score = 0;
    		jump_state = 0;
    		for(int i = 0; i < n; i++){
    			for(int j = 0; j < m; j++){
    				game[i][j] = 0;
    			}
    		}
    		go_next_mode();
    	}
    }
}

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */



/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM4_Init();
  MX_TIM3_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
  LiquidCrystal(GPIOD, GPIO_PIN_1, GPIO_PIN_2, GPIO_PIN_3,GPIO_PIN_4, GPIO_PIN_5, GPIO_PIN_6, GPIO_PIN_7);
  begin(20,4);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  PWM_Start();
  createChar(0, ground);
  createChar(1, first);
  createChar(2, second);
  createChar(3, third);
  createChar(4, peh);
  createChar(5, reh);
  createChar(6, sheh);

  HAL_TIM_Base_Start_IT(&htim3);
  HAL_TIM_Base_Start_IT(&htim4);
  while(1){
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 4294967295;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 4799;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 9999;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 479;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 399;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, CS_I2C_SPI_Pin|GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10
                          |GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14
                          |GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15
                          |GPIO_PIN_8, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11
                          |GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_9, GPIO_PIN_RESET);

  /*Configure GPIO pins : DRDY_Pin MEMS_INT3_Pin MEMS_INT4_Pin MEMS_INT2_Pin */
  GPIO_InitStruct.Pin = DRDY_Pin|MEMS_INT3_Pin|MEMS_INT4_Pin|MEMS_INT2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_EVT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pins : CS_I2C_SPI_Pin PE8 PE9 PE10
                           PE11 PE12 PE13 PE14
                           PE15 */
  GPIO_InitStruct.Pin = CS_I2C_SPI_Pin|GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10
                          |GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14
                          |GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pin : PA0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PA5 PA6 PA7 */
  GPIO_InitStruct.Pin = GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB12 PB13 PB14 PB15
                           PB8 */
  GPIO_InitStruct.Pin = GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15
                          |GPIO_PIN_8;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PD8 PD9 PD10 PD11
                           PD12 PD13 PD14 PD15 */
  GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11
                          |GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pins : PC6 PC7 PC9 */
  GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : DM_Pin DP_Pin */
  GPIO_InitStruct.Pin = DM_Pin|DP_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF14_USB;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : I2C1_SCL_Pin I2C1_SDA_Pin */
  GPIO_InitStruct.Pin = I2C1_SCL_Pin|I2C1_SDA_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF4_I2C1;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI0_IRQn);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
