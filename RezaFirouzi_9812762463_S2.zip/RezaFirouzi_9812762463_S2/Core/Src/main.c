#include "stm32f3xx_hal.h"

int botton;
int state;
int number1;
int number2;

void initForLeds()
{
	/*
			initialization for enabling PORTE for OUTPUT LEDs
		*/
	__HAL_RCC_GPIOE_CLK_ENABLE();
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.Pin = GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11 |
			GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15;
//	GPIO_InitStruct.Pin = 0b00000000000000001111111100000000;
//	GPIO_InitStruct.Pin = 0xFF00U; // GPIO_PIN_8 ... 15
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);
}

void initForExtraLeds()
{
	/*
			initialization for enabling PORTE for OUTPUT LEDs
		*/
	__HAL_RCC_GPIOA_CLK_ENABLE();
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.Pin = GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10;
//	GPIO_InitStruct.Pin = 0b00000000000000001111111100000000;
//	GPIO_InitStruct.Pin = 0xFF00U; // GPIO_PIN_8 ... 15
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

// pd1 = a , pd2 = b , pd3 = c ... pd7 = g
// pd0 = dp
// pd8 = LED1 , pd9 = LED2 , pd10 = LED3
// pd11 = d1
// pd12 = d2
// pd13 = d3
// pd14 = d4
void initForPortD()
{
	/*
			initialization for enabling PORTE for OUTPUT LEDs
		*/
	__HAL_RCC_GPIOD_CLK_ENABLE();
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.Pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 |
			GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7 |
			GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11 |
			GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15;
//	GPIO_InitStruct.Pin = 0b00000000000000001111111111111111;
//	GPIO_InitStruct.Pin = 0xFF00U; // GPIO_PIN_8 ... 15
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
}


void initForBlueButton()
{
	/*
			initialization for enabling PORTA for BLUE-BUTTON
		*/
	__HAL_RCC_GPIOA_CLK_ENABLE();
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.Pin = GPIO_PIN_0;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

void display_LED(int mode)
{
	if(mode == 1){
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, 1);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, 0);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, 0);
	}
	if(mode == 2){
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, 1);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, 1);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, 0);

	}
	if(mode == 3){
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, 1);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, 1);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, 1);

	}
}
void display_number(int a, int dp)
{
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_0, 1);
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_1, 1);
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, 1);
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_3, 1);
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_4, 1);
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_5, 1);
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_6, 1);
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_7, 1);
	if(dp == 1){
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_0, 0);
	}
	if(a == 0){
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_1, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_3, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_4, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_5, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_6, 0);
	}
	if(a == 1){
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_3, 0);
	}
	if(a == 2){
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_1, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_7, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_5, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_4, 0);
	}
	if(a == 3){
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_1, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_7, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_3, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_4, 0);
	}
	if(a == 4){
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_6, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_7, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_3, 0);
	}
	if(a == 5){
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_1, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_3, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_4, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_6, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_7, 0);
	}
	if(a == 6){
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_1, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_3, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_4, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_5, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_6, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_7, 0);
	}
	if(a == 7){
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_1, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_3, 0);
	}
	if(a == 8){
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_1, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_3, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_4, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_5, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_6, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_7, 0);
	}
	if(a == 9){
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_1, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_3, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_4, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_6, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_7, 0);
	}

}
void show_all(int a, int dp)
{
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11, 1);
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, 1);
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, 1);
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, 1);
	display_number(a, dp);
}
void display_segment(int a, int b, int c, int d, int dp1, int dp2, int dp3, int dp4, int delay)
{
	if(delay == 0){
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11, 1);
			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, 0);
			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, 0);
			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, 0);
			display_number(a, dp1);
			HAL_Delay(5);
			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11, 0);
			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, 1);
			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, 0);
			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, 0);
			display_number(b, dp2);
			HAL_Delay(5);
			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11, 0);
			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, 0);
			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, 1);
			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, 0);
			display_number(c, dp3);
			HAL_Delay(5);
			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11, 0);
			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, 0);
			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, 0);
			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, 1);
			display_number(d, dp4);
			HAL_Delay(5);
			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11, 0);
			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, 0);
			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, 0);
			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, 0);
	}

	for(int i = 0; i < delay / 20; i++){
					HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11, 1);
					HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, 0);
					HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, 0);
					HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, 0);
					display_number(a, dp1);
					HAL_Delay(5);
					HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11, 0);
					HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, 1);
					HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, 0);
					HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, 0);
					display_number(b, dp2);
					HAL_Delay(5);
					HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11, 0);
					HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, 0);
					HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, 1);
					HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, 0);
					display_number(c, dp3);
					HAL_Delay(5);
					HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11, 0);
					HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, 0);
					HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, 0);
					HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, 1);
					display_number(d, dp4);
					HAL_Delay(5);
					HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11, 0);
					HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, 0);
					HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, 0);
					HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, 0);
	}

}


void sub_problem1()
{
	int a,b,c,d;
	while(1){
		a = number1/1000;
		b = number1/100;
		c = number1/10;
		d = number1;
		display_segment(a%10, b%10, c%10, d%10, 0, 0, 0, 0, 0);
		if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == 1 && botton == 0){
			botton = 1;
		}
		if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == 0 && botton == 1){
			botton = 0;
			number1++;
		}
	}
}

void sub_problem2()
{
	while(number1 < 30){
		display_segment(number1/10, number1%10, 0, 0, 0, 1, 0, 0, 100);
		if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == 1 && botton == 0){
			botton = 1;
		}
		if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == 0 && botton == 1){
			botton = 0;
			break;
		}
		number1++;
	}
	while(1){
		display_segment(number1/10, number1%10, number2/10, number2%10, 0, 1, 0, 0, number1*100);
		number2 = (number2 + 1) % 100;
	}

}
void sub_problem3()
{
	while(1){
		display_segment((number1+1)/10, (number1+1)%10, 0, 0, 0, 1, 0, 0, 500);
		if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == 1 && botton == 0){
			botton = 1;
		}
		if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == 0 && botton == 1){
			botton = 0;
			break;
		}
		number1 = (number1 + 1) % 10;
	}
	number1++;
	while(1){
		display_segment(number1/10, number1%10, number2/10, number2%10, 0, 1, 0, 0, 0);
		if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == 1 && botton == 0){
			botton = 1;
		}
		if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == 0 && botton == 1){
			botton = 0;
			number2 += number1;
		}
	}
}
int main()
{

	initForLeds();
	initForExtraLeds();
	initForPortD();
	initForBlueButton();
	HAL_SYSTICK_Config(SystemCoreClock / (1000U / 1));


	state = 0;
	number1 = 0;
	number2 = 0;
	while (1)
	{
		show_all(state+1, 0);
		HAL_Delay(1000);
		if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == 1 && botton == 0){
			botton = 1;
		}
		if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == 0 && botton == 1){
			botton = 0;
			break;
		}
		state = (state+1) % 3;

	}
	display_LED(state+1);
	if(state == 0){
		sub_problem1();
	}
	if(state == 1){
		sub_problem2();
	}
	if(state == 2){
		sub_problem3();
	}
}
