/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
#include "LiquidCrystal.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef unsigned char byte;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
byte board[8] = {
        0x01,
          0x01,
          0x01,
          0x01,
          0x01,
          0x01,
          0x01,
          0x01
};
byte broken_board[8] = {
        0x01,
          0x01,
          0x01,
          0x00,
          0x00,
          0x01,
          0x01,
          0x01
};
byte coil[8] = {
        0x01,
          0x01,
          0x03,
          0x07,
          0x07,
          0x03,
          0x01,
          0x01
};
byte black_hole[8] = {
        0x1F,
  0x1F,
  0x1F,
  0x1F,
  0x1F,
  0x1F,
  0x1F,
  0x1F
};


byte monster[8] = {
        0x03,
          0x04,
          0x0C,
          0x1F,
          0x1F,
          0x0C,
          0x04,
          0x03
};

byte doodle[8] = {
        0x00,
          0x0E,
          0x1C,
          0x1E,
          0x1E,
          0x1C,
          0x0E,
          0x00
};

byte doodle_on_board[8] = {
        0x01,
          0x0F,
          0x1D,
          0x1F,
          0x1F,
          0x1D,
          0x0F,
          0x01
};

byte doodle_on_coil[8] = {
        0x01,
          0x0F,
          0x1D,
          0x1F,
          0x1F,
          0x1D,
          0x0F,
          0x01
};

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
char name[10] = "doodle";

unsigned char data[50] = "\n";
unsigned char c[1];
int position = 0;

int odd_even_tick;
int volume;
int hardness;
int score;
int jump;
int show;
char pm[20];
int seven_segment_enable;
// if jump == 0 go down
// while(jump--) go up
int mode = -1;
// mode-1 : name and a view of game
// mode 0 : menu
// mode 1 : about
// mode 2 : start animation
// mode 3 : game
// mode 4 : end animation
// mode 5 : game over
// mode 6 : artificial intelligence
int animation_count;
int x;
int y;
// game[x][y] = doodle

// while(animation_count--) show or remove row
int game[4][20];
int updated_game[4][20];
// game[i][j] = 0 : empty
// game[i][j] = 1 : board
// game[i][j] = 2 : broken board
// game[i][j] = 3 : coil
// game[i][j] = 4 : black hole
// game[i][j] = 5 : monster
// game[i][j] = 6 : doodle
// game[i][j] = 7 : doodle on board
// game[i][j] = 8 : doodle on coil

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc3;

RTC_HandleTypeDef hrtc;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
TIM_HandleTypeDef *pwm_timer = &htim2; // Point to PWM timer configured in CubeMX
uint32_t pwm_channel = TIM_CHANNEL_2;  // Specify configured PWM channel

void PWM_Start()
{
  HAL_TIM_PWM_Start(pwm_timer, pwm_channel);
}

void PWM_Change_Tone(uint16_t pwm_freq, uint16_t volume) // pwm_freq (1 - 20000), volume (0 - 1000)
{
  if (pwm_freq == 0 || pwm_freq > 20000)
  {
    __HAL_TIM_SET_COMPARE(pwm_timer, pwm_channel, 0);
  }
  else
  {
    const uint32_t internal_clock_freq = HAL_RCC_GetSysClockFreq();
    const uint16_t prescaler = 1;
    const uint32_t timer_clock = internal_clock_freq / prescaler;
    const uint32_t period_cycles = timer_clock / pwm_freq;
    const uint32_t pulse_width = volume * period_cycles / 1000 / 2;

    pwm_timer->Instance->PSC = prescaler - 1;
    pwm_timer->Instance->ARR = period_cycles - 1;
    pwm_timer->Instance->EGR = TIM_EGR_UG;
    __HAL_TIM_SET_COMPARE(pwm_timer, pwm_channel, pulse_width); // pwm_timer->Instance->CCR2 = pulse_width;
  }
}


void send_log(int CASE)
{
    RTC_TimeTypeDef mytime;
      RTC_DateTypeDef mydate;
      char log[100];
      HAL_RTC_GetTime(&hrtc, &mytime, RTC_FORMAT_BIN);
      HAL_RTC_GetDate(&hrtc, &mydate, RTC_FORMAT_BIN);
    if(CASE == 0){ // moved to left
        sprintf(log, "%s moved to left in this time\n %2d/%2d/%2d at %2d:%2d:%2d\n",

                      name, mydate.Year, mydate.Month, mydate.Date,
                      mytime.Hours, mytime.Minutes, mytime.Seconds);
    }
    if(CASE == 1){ // moved to right
        sprintf(log, "%s moved to right in this time\n %2d/%2d/%2d at %2d:%2d:%2d\n",
                      name, mydate.Year, mydate.Month, mydate.Date,
                      mytime.Hours, mytime.Minutes, mytime.Seconds);
    }
    if(CASE == 2){ // fired bullet
        sprintf(log, "%s fired a bullet in this time\n %2d/%2d/%2d at %2d:%2d:%2d\n",
                      name, mydate.Year, mydate.Month, mydate.Date,
                      mytime.Hours, mytime.Minutes, mytime.Seconds);
    }

    // send uart
    HAL_UART_Transmit(&huart2,log ,sizeof(unsigned char) * strlen(log),1000);
}

void display_number(int a, int dp)
{
    // d0, d1, d2, d3 = numbers
    // d11, d12, d13 , d14 = enable
    // d15 = dp
    // c6 , c7 ,c8 ,c9 = external button
    // a1 = buzzer
    // a2 = tx
    // a3 = rx
    // b4 = time ch1
    // a4 = tim3 ch2
    // b0 = tim3 ch3
    // b1 = tim3 ch4
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, 1);
    if(dp == 1) HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, 0);
    int x1 = a & 1;
    int x2 = a & 2;
    int x3 = a & 4;
    int x4 = a & 8;
    if(x1 > 0) x1 = 1;
    if(x2 > 0) x2 = 1;
    if(x3 > 0) x3 = 1;
    if(x4 > 0) x4 = 1;

    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, x1);
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, x2);
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, x3);
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, x4);

}

void turn_off()
{
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, 0);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, 0);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, 0);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, 0);
}

void show_all(int a, int dp)
{
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, 1);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, 1);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, 1);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, 1);
    display_number(a, dp);
}

void update_game()
{
    for(int i = 0; i < 4; i++){
        for(int j = 0; j < 20; j++){
            game[i][j] = updated_game[i][j];
        }
    }
}
void place_cursor(int i, int j)
{
    setCursor(19-j, 3-i);
}

void update_cell(int i, int j)
{
    setCursor(19-j, 3-i);
    if(updated_game[i][j] == 0){
        print(" ");
    }
    else{
        write(updated_game[i][j]);
    }
}

int probablity(int number, int p) // 0 < p < 100
{
    long long q = rand();
    q *= 100;
    long long w = p;
    w *= RAND_MAX;
    if(q < w){
        return 1;
    }
    return 0;
}

int which_one()
{
    int r = rand();
    int base;
    if(probablity(r, 8 - hardness/3)){
        return 1;
    }
    if(probablity(r, 2)){
        return 2;
    }
    if(probablity(r, 7 - hardness/2)){
        return 3;
    }
    if(probablity(r, (hardness/5) + 4)){
        return 4;
    }
    if(probablity(r, hardness/2)){
        return 5;
    }
}
void initialize_game()
{
    // initialize_game
    for(int i = 0; i < 4; i++){
        for(int j = 1; j < 20; j++){
            updated_game[i][j] = which_one();
        }
    }
    for(int i = 0; i < 4; i++){
        updated_game[i][0] = 0;
    }
    for(int i = 0; i < 4; i++){
        if(updated_game[i][1] == 4 || updated_game[i][1] == 5){
            updated_game[i][1] = 0;
        }
    }
    updated_game[2][0] = 7;
    x = 2;
    y = 0;
    update_game();


}
void fire_bullet()
{
    send_log(2);
    // kill monster
    for(int j = y; j < 20; j++){
        if(updated_game[x][j] == 5){
            updated_game[x][j] = 0;
            return;
        }
    }
}


void pick_up()
{
    int i = x;
    int j = y;
    if(updated_game[i][j] == 6){
        updated_game[i][j] = 0;
    }
    if(updated_game[i][j] == 7){
        updated_game[i][j] = 1;
    }
    if(updated_game[i][j] == 8){
        updated_game[i][j] = 3;
    }
}

void put_down()
{
    int i = x;
    int j = y;
    if(updated_game[i][j] == 0){
        updated_game[i][j] = 6;
    }
    if(updated_game[i][j] == 1){
        updated_game[i][j] = 7;
    }
    if(updated_game[i][j] == 2){
        updated_game[i][j] = 6;
    }
    if(updated_game[i][j] == 3){
        updated_game[i][j] = 8;
    }
    if(updated_game[i][j] == 4){
        updated_game[i][j] = 4;
    }
    if(updated_game[i][j] == 5){
        updated_game[i][j] = 5;
        jump = -1;
        PWM_Change_Tone(10, 1);
    }
}

void move_down()
{
    pick_up();
    for(int j = 0; j < 19; j++){
        for(int i = 0; i < 4; i++){
            updated_game[i][j] = updated_game[i][j+1];
        }
    }
    int j = 19;
    for(int i = 0; i < 4; i++){
        updated_game[i][j] = which_one();
    }
    score += hardness;
    put_down();
}

void jump_up()
{
    pick_up();
    y++;
    put_down();
}

void go_down()
{
    pick_up();
    y--;
    put_down();
}
void go_left()
{
    send_log(0);
    pick_up();
    x--;
    x += 4;
    x %= 4;
    put_down();
}
void go_right(){
    send_log(1);
    pick_up();
    x++;
    x %= 4;
    put_down();
}




// Input pull down rising edge trigger interrupt pins:
// Row1 PD3, Row2 PD5, Row3 PD7, Row4 PB4
GPIO_TypeDef *const Row_ports[] = {GPIOC, GPIOC, GPIOC, GPIOC};
const uint16_t Row_pins[] = {GPIO_PIN_4, GPIO_PIN_1, GPIO_PIN_2, GPIO_PIN_3};
// Output pins: Column1 PD4, Column2 PD6, Column3 PB3, Column4 PB5
GPIO_TypeDef *const Column_ports[] = {GPIOC, GPIOC, GPIOC, GPIOC};
const uint16_t Column_pins[] = {GPIO_PIN_10, GPIO_PIN_11, GPIO_PIN_12, GPIO_PIN_13};
volatile uint32_t last_gpio_exti;

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  if (last_gpio_exti + 400 > HAL_GetTick()) // Simple button debouncing
  {
    return;
  }
  last_gpio_exti = HAL_GetTick();

  int8_t row_number = -1;
  int8_t column_number = -1;

  for (uint8_t row = 0; row < 4; row++) // Loop through Rows
  {
    if (GPIO_Pin == Row_pins[row])
    {
      row_number = row;
    }
  }
  HAL_GPIO_WritePin(Column_ports[0], Column_pins[0], 0);
  HAL_GPIO_WritePin(Column_ports[1], Column_pins[1], 0);
  HAL_GPIO_WritePin(Column_ports[2], Column_pins[2], 0);
  HAL_GPIO_WritePin(Column_ports[3], Column_pins[3], 0);

  for (uint8_t col = 0; col < 4; col++) // Loop through Columns
  {
    HAL_GPIO_WritePin(Column_ports[col], Column_pins[col], 1);
    if (HAL_GPIO_ReadPin(Row_ports[row_number], Row_pins[row_number]))
    {
      column_number = col;
    }
    HAL_GPIO_WritePin(Column_ports[col], Column_pins[col], 0);
  }
  HAL_GPIO_WritePin(Column_ports[0], Column_pins[0], 1);
  HAL_GPIO_WritePin(Column_ports[1], Column_pins[1], 1);
  HAL_GPIO_WritePin(Column_ports[2], Column_pins[2], 1);
  HAL_GPIO_WritePin(Column_ports[3], Column_pins[3], 1);





  if (row_number == -1 || column_number == -1)
  {
    // blue botton
    if(mode == -1){
        mode = 0;
        show = 0;
    }
    if(mode == 1){
        mode = 0;
        show = 0;
    }
    if(mode == 5){
        mode = 0;
        show = 0;
        score = 0;

    }
    return;

  }
  //   C0   C1   C2   C3
  // +----+----+----+----+
  // | 1  | 2  | 3  | 4  |  R0
  // +----+----+----+----+
  // | 5  | 6  | 7  | 8  |  R1
  // +----+----+----+----+
  // | 9  | 10 | 11 | 12 |  R2
  // +----+----+----+----+
  // | 13 | 14 | 15 | 16 |  R3
  // +----+----+----+----+

  const uint8_t button_number = row_number * 4 + column_number + 1;
  switch (button_number)
  {
  case 1:
      if(mode == 3){
          fire_bullet();
      }
    break;

  case 2:
    break;

  case 3:
    break;

  case 4:
      // about
        if(mode == 0){
            mode = 1;
            show = 0;
        }
    break;

  case 5:
  // move right
     if(mode == 3){
         go_right();
     }

    break;

  case 6:
    break;

  case 7:
    break;

  case 8:
  // start game
  if(mode == 0){
    mode = 2;
    show = 0;
    initialize_game();
    animation_count = 20;
  }
    break;

  case 9:
    // fire a bullet
     if(mode == 3){
         fire_bullet();
     }
    break;

  case 10:
    break;

  case 11:
    break;

  case 12:

    break;

  case 13:
    // move left
    if(mode == 3){
        go_left();
    }


    break;

  case 14:
    break;

  case 15:
    break;

  case 16:
// artificial intelligence
      if(mode == 0){
          mode = 6;
          show = 0;
          initialize_game();
          animation_count = 20;
      }
    break;

  default:

    break;
  }
}
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM3_Init(void);
static void MX_ADC3_Init(void);
static void MX_RTC_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM4_Init(void);
static void MX_TIM2_Init(void);
/* USER CODE BEGIN PFP */



int is_dead()
{
    if(updated_game[x][y] == 4){
        return 1;
    }
    if(y == 0 && updated_game[x][y] != 7 && updated_game[x][y] != 8){
        return 1;
    }
    if(y == 0 && jump == -1){
        return 1;
        PWM_Change_Tone(1, 0);
    }
    return 0;
}

void show_game()
{
    for(int j = 19; j >= 0; j--){
        for(int i = 3; i >= 0; i--){
            if(game[i][j] != updated_game[i][j]){
                update_cell(i, j);
            }
        }
    }
}




void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2)
    {
        if(c[0] != 0x0D){
            data[position] = c[0];
            position++;

        }
        else{
            data[position] = '\0';
            position = 0;
            if(mode == 0){
                unsigned char text1[50] = "name changed\n\0";
                for(int i = 0; i <= strlen(data); i++){
                    name[i] = data[i];
                }
                HAL_UART_Transmit(&huart2, text1, sizeof(unsigned char) * strlen(text1), 1000);
            }
            else{
                unsigned char text1[50] = "you can't change name\n\0";
                HAL_UART_Transmit(&huart2, text1, sizeof(unsigned char) * strlen(text1), 1000);
            }
        }
        HAL_UART_Receive_IT(&huart2, c, sizeof(c));
    }
}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{


    if (hadc->Instance == ADC3)
    {
        volume = HAL_ADC_GetValue(&hadc3);
        hardness = volume * 10 / 4200;
    }

}


void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if(htim->Instance == TIM3) // seven segment 0.05 s
    {
        if(seven_segment_enable == 0){
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, 1);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, 0);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, 0);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, 0);
            display_number(hardness, 1);
        }
        if(seven_segment_enable == 1){
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, 0);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, 1);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, 0);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, 0);
            display_number(score / 100, 0);
        }
        if(seven_segment_enable == 2){
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, 0);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, 0);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, 1);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, 0);
            display_number((score/10) % 10, 0);
        }
        if(seven_segment_enable == 3){
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, 0);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, 0);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, 0);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, 1);
            display_number(score%10, 0);
        }
        seven_segment_enable++;
        seven_segment_enable %= 4;

    }
    if (htim->Instance == TIM4) // game every 0.5 second
    {
        HAL_ADC_Start_IT(&hadc3);
        if(mode == -1){
            if(show == 0){
                clear();
                // TODO show name and a view of game
                print("doodle jump");
                setCursor(0, 1);
                print("     ");
                write(5);
                print("      ");
                write(4);
                setCursor(0, 2);
                print("          ");
                write(3);
                print("   ");
                write(2);
                setCursor(0, 3);
                print("  ");
                write(1);
                print("             ");
                write(7);
                show = 1;
            }
        }
        if(mode == 0){
            if(show == 0){
                clear();
                setCursor(5, 0);
                print("start game");
                setCursor(5, 1);
                print("AI player");
                setCursor(7, 2);
                print("about");
                setCursor(0, 3);
                print("change name via UART");
                show = 1;
            }
        }
        if(mode == 1){
            if(show == 0){
                clear();
                print("Ali Adelkhah");
                setCursor(0, 1);
                print("seyyed reza firouzi");
                show = 1;
            }

            if(odd_even_tick == 0){
                RTC_TimeTypeDef mytime;
                RTC_DateTypeDef mydate;

                char Stime[20];
                char Sdate[20];

              HAL_RTC_GetTime(&hrtc, &mytime, RTC_FORMAT_BIN);
              HAL_RTC_GetDate(&hrtc, &mydate, RTC_FORMAT_BIN);

              setCursor(0, 2);
              sprintf(Stime, "%2d:%2d:%2d", mytime.Hours, mytime.Minutes, mytime.Seconds);
              print(Stime);

              setCursor(0, 3);
              sprintf(Sdate, "%2d/%2d/%2d", mydate.Year, mydate.Month, mydate.Date);
              print(Sdate);

            }
            odd_even_tick++;
            odd_even_tick %= 2;
        }
        if(mode == 2){ // start
            if(animation_count == 20){
                clear();
            }
            for(int i = 0; i < 4; i++){
                update_cell(i, animation_count-1);
            }
            for(int i = 0; i < 4; i++){
                if(animation_count == 1){
                    continue;
                }
                place_cursor(i, animation_count-2);
                write(4);
            }
            animation_count--;
            if(animation_count == 0){
                mode = 3;
                show = 0;
            }
        }

        if(mode == 3){
            // TODO play game
            if(is_dead()){
                mode = 4;
                animation_count = 20;
                show = 0;
                return;
            }
            if(jump == -1){
                go_down();
            }
            else if(jump > 0){
                jump--;
                if(y == 10){
                    move_down();
                }
                else{
                    jump_up();
                }
            }
            else{
                if(game[x][y] == 7){
                    jump = 7;
                    PWM_Change_Tone(4, 1);
                }
                else if(game[x][y] == 8){
                    jump = 20;
                    PWM_Change_Tone(4, 1);
                }
                else{
                    PWM_Change_Tone(1, 0);
                    go_down();
                }

            }
            show_game();
            update_game();
        }
        if(mode == 4){ // end
            PWM_Change_Tone(1, 0);
            for(int i = 0; i < 4; i++){
                for(int j = 0; j < 20; j++){
                    updated_game[i][j] = 0;
                }
            }
            for(int i = 0; i < 4; i++){
                update_cell(i, 20-animation_count);
            }
            for(int i = 0; i < 4; i++){
                place_cursor(i, 21-animation_count);
                write(4);
            }
            animation_count--;
            if(animation_count == 0){
                mode = 5;
                show = 0;
            }
        }
        if(mode == 5){
            if(show == 0){
                clear();
                sprintf(pm, "%d score for %s", score, name);
                print("game over");
                setCursor(0, 1);
                print(pm);
                // TODO show game over
                show = 1;
            }
            if(odd_even_tick == 0){
                HAL_GPIO_WritePin(GPIOE, GPIO_PIN_8, 1);
                HAL_GPIO_WritePin(GPIOE, GPIO_PIN_9, 1);
                HAL_GPIO_WritePin(GPIOE, GPIO_PIN_10, 1);
                HAL_GPIO_WritePin(GPIOE, GPIO_PIN_11, 1);
                HAL_GPIO_WritePin(GPIOE, GPIO_PIN_12, 1);
                HAL_GPIO_WritePin(GPIOE, GPIO_PIN_13, 1);
                HAL_GPIO_WritePin(GPIOE, GPIO_PIN_14, 1);
                HAL_GPIO_WritePin(GPIOE, GPIO_PIN_15, 1);
            }
            else{
                HAL_GPIO_WritePin(GPIOE, GPIO_PIN_8, 0);
                HAL_GPIO_WritePin(GPIOE, GPIO_PIN_9, 0);
                HAL_GPIO_WritePin(GPIOE, GPIO_PIN_10, 0);
                HAL_GPIO_WritePin(GPIOE, GPIO_PIN_11, 0);
                HAL_GPIO_WritePin(GPIOE, GPIO_PIN_12, 0);
                HAL_GPIO_WritePin(GPIOE, GPIO_PIN_13, 0);
                HAL_GPIO_WritePin(GPIOE, GPIO_PIN_14, 0);
                HAL_GPIO_WritePin(GPIOE, GPIO_PIN_15, 0);
            }
            odd_even_tick++;
            odd_even_tick %= 2;
        }
        if(mode == 6){ // start ai
            if(animation_count == 20){
                clear();
            }
            for(int i = 0; i < 4; i++){
                update_cell(i, animation_count-1);
            }
            for(int i = 0; i < 4; i++){
                if(animation_count == 1){
                    continue;
                }
                place_cursor(i, animation_count-2);
                write(4);
            }
            animation_count--;
            if(animation_count == 0){
                mode = 7;
                show = 0;
                return;
            }
        }
        if(mode == 7){
            // ai plays
            // TODO play game
            if(is_dead()){
                mode = 4;
                animation_count = 20;
                show = 0;
                return;
            }

            if(jump == -1){
                go_down();
            }
            else if(jump > 0){

                //////////////////////////////////////
                jump--;
                if(y == 10){
                    move_down();
                }
                else{
                    jump_up();
                }
                ////////////////////////////////////////
                fire_bullet();
                int last[4];
                for(int i = 0; i < 4; i++){
                    last[i] = 20;
                }
                for(int i = 0; i < 4; i++){
                    for(int j = y; j < 20; j++){
                        if(updated_game[i][j] == 4){
                            last[i] = j;
                            break;
                        }
                    }
                }

                /////////////


                int best_jump[4];
                best_jump[0] = -1;
                best_jump[1] = -1;
                best_jump[2] = -1;
                best_jump[3] = -1;
                for(int i = 0; i < 4; i++){
                    int maxj = y + jump;
                    if(last[i]-1 < y + jump){
                        maxj = last[i] -1;
                    }
                    for(int j = y; j <= maxj; j++){
                        if(updated_game[i][j] == 1){
                            best_jump[i] = 7 + j;
                        }
                        if(updated_game[i][j] == 3){
                            best_jump[i] = 20 + j;
                        }
                    }
                }

                int id = -1;
                int maxip = -1;
                for(int i = 0; i < 4; i++){
                    if(maxip < best_jump[i]){
                        id = i;
                        maxip = best_jump[i];
                    }
                }
                if(id == -1){
                    id = x;
                }

                int q = (id - x + 4) % 4;
                while(q--){
                    go_right();
                    fire_bullet();
                }

            }
            else{

                ///////////////////////////////////////
                if(game[x][y] == 7){
                    jump = 7;
                    PWM_Change_Tone(4, 1);
                }
                else if(game[x][y] == 8){
                    jump = 20;
                    PWM_Change_Tone(4, 1);
                }
                else{
                    PWM_Change_Tone(1, 0);

                    go_down();

                    int last[4];
                    for(int i = 0; i < 4; i++){
                        last[i] = -1;
                    }
                    for(int i = 0; i < 4; i++){
                        for(int j = y; j >= 0; j--){
                            if(game[i][j] == 4 || game[i][j] == 5){
                                last[i] = j;
                                break;
                            }
                        }
                    }

                    int best_jump[4];
                    best_jump[0] = -1;
                    best_jump[1] = -1;
                    best_jump[2] = -1;
                    best_jump[3] = -1;
                    for(int i = 0; i < 4; i++){
                        for(int j = y; j > last[i]; j--){
                            if(game[i][j] == 3){
                                best_jump[i] = 20 + j;
                                break;
                            }
                            if(game[i][j] == 1){
                                best_jump[i] = 7 + j;
                                break;
                            }
                        }
                    }

                    int id = -1;
                    int maxip = -1;
                    for(int i = 0; i < 4; i++){
                        if(maxip < best_jump[i]){
                            id = i;
                            maxip = best_jump[i];
                        }
                    }
                    if(id == -1){
                        id = x;
                    }
                    int q = (id - x + 4) % 4;
                    while(q--){
                        go_right();
                        fire_bullet();
                    }

                }
            }
            show_game();
            update_game();
        }
    }
}

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */



/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM3_Init();
  MX_ADC3_Init();
  MX_RTC_Init();
  MX_USART2_UART_Init();
  MX_TIM4_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
  LiquidCrystal(GPIOD, GPIO_PIN_1, GPIO_PIN_2, GPIO_PIN_3,GPIO_PIN_4, GPIO_PIN_5, GPIO_PIN_6, GPIO_PIN_7);
  begin(20,4);

  RTC_TimeTypeDef mytime;
  mytime.Hours = 6;
  mytime.Minutes = 27;
  mytime.Seconds = 5;
  HAL_RTC_SetTime(&hrtc, &mytime, RTC_FORMAT_BIN);
  RTC_DateTypeDef mydate;
  mydate.Year = 22;
  mydate.Month = 3;
  mydate.Date = 5;
  HAL_RTC_SetDate(&hrtc, &mydate, RTC_FORMAT_BIN);

  HAL_TIM_Base_Start_IT(&htim3);
  HAL_TIM_Base_Start_IT(&htim4);
  PWM_Start();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  createChar(1, board);
  createChar(2, broken_board);
  createChar(3, coil);
  createChar(4, black_hole);
  createChar(5, monster);
  createChar(6, doodle);
  createChar(7, doodle_on_board);
  createChar(8, doodle_on_coil);

  srand(volume);
  HAL_UART_Receive_IT(&huart2, c,sizeof(c));

  while(1){
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */


  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART2|RCC_PERIPHCLK_RTC
                              |RCC_PERIPHCLK_ADC34;
  PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
  PeriphClkInit.Adc34ClockSelection = RCC_ADC34PLLCLK_DIV1;
  PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSI;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC3_Init(void)
{

  /* USER CODE BEGIN ADC3_Init 0 */

  /* USER CODE END ADC3_Init 0 */

  ADC_MultiModeTypeDef multimode = {0};
  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC3_Init 1 */

  /* USER CODE END ADC3_Init 1 */
  /** Common config
  */
  hadc3.Instance = ADC3;
  hadc3.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc3.Init.Resolution = ADC_RESOLUTION_12B;
  hadc3.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc3.Init.ContinuousConvMode = DISABLE;
  hadc3.Init.DiscontinuousConvMode = DISABLE;
  hadc3.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc3.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc3.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc3.Init.NbrOfConversion = 1;
  hadc3.Init.DMAContinuousRequests = DISABLE;
  hadc3.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc3.Init.LowPowerAutoWait = DISABLE;
  hadc3.Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;
  if (HAL_ADC_Init(&hadc3) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure the ADC multi-mode
  */
  multimode.Mode = ADC_MODE_INDEPENDENT;
  if (HAL_ADCEx_MultiModeConfigChannel(&hadc3, &multimode) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_12;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc3, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC3_Init 2 */

  /* USER CODE END ADC3_Init 2 */

}

/**
  * @brief RTC Initialization Function
  * @param None
  * @retval None
  */
static void MX_RTC_Init(void)
{

  /* USER CODE BEGIN RTC_Init 0 */

  /* USER CODE END RTC_Init 0 */

  /* USER CODE BEGIN RTC_Init 1 */

  /* USER CODE END RTC_Init 1 */
  /** Initialize RTC Only
  */
  hrtc.Instance = RTC;
  hrtc.Init.HourFormat = RTC_HOURFORMAT_24;
  hrtc.Init.AsynchPrediv = 127;
  hrtc.Init.SynchPrediv = 255;
  hrtc.Init.OutPut = RTC_OUTPUT_DISABLE;
  hrtc.Init.OutPutPolarity = RTC_OUTPUT_POLARITY_HIGH;
  hrtc.Init.OutPutType = RTC_OUTPUT_TYPE_OPENDRAIN;
  if (HAL_RTC_Init(&hrtc) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN RTC_Init 2 */

  /* USER CODE END RTC_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 4294967295;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 479;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 999;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 4799;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 4999;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, CS_I2C_SPI_Pin|GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10
                          |GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14
                          |GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13|GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8
                          |GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_13
                          |GPIO_PIN_14|GPIO_PIN_15|GPIO_PIN_5|GPIO_PIN_8
                          |GPIO_PIN_9, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11
                          |GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pins : CS_I2C_SPI_Pin PE8 PE9 PE10
                           PE11 PE12 PE13 PE14
                           PE15 */
  GPIO_InitStruct.Pin = CS_I2C_SPI_Pin|GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10
                          |GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14
                          |GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pins : PC13 PC6 PC7 PC8
                           PC9 PC10 PC11 PC12 */
  GPIO_InitStruct.Pin = GPIO_PIN_13|GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8
                          |GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PC1 PC2 PC3 PC4 */
  GPIO_InitStruct.Pin = GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PA0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PA5 PA6 PA7 */
  GPIO_InitStruct.Pin = GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PC5 */
  GPIO_InitStruct.Pin = GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PB10 PB11 PB12 PB13
                           PB14 PB15 PB5 PB8
                           PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_13
                          |GPIO_PIN_14|GPIO_PIN_15|GPIO_PIN_5|GPIO_PIN_8
                          |GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PD8 PD9 PD10 PD11
                           PD12 PD13 PD14 PD15 */
  GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11
                          |GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pins : DM_Pin DP_Pin */
  GPIO_InitStruct.Pin = DM_Pin|DP_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF14_USB;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : I2C1_SCL_Pin I2C1_SDA_Pin */
  GPIO_InitStruct.Pin = I2C1_SCL_Pin|I2C1_SDA_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF4_I2C1;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI0_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(EXTI0_IRQn);

  HAL_NVIC_SetPriority(EXTI1_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(EXTI1_IRQn);

  HAL_NVIC_SetPriority(EXTI3_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(EXTI3_IRQn);

  HAL_NVIC_SetPriority(EXTI4_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(EXTI4_IRQn);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
